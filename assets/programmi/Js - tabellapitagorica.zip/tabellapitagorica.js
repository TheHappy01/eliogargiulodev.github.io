//Autore: Elio Gargiulo

        var n = prompt("Inserisci N:");
        var molt;

        while (isNaN(n) == true || n == null || n == "" )
        {
            alert("Errore. Inserire un numero adeguato.");
            n = prompt("Inserisci N:");
        }
        n = parseInt(n);
        document.write("<p>Tabella pitagorica da 1 a " + n + "</p>");
        document.write("<table border=\"1\">");
        for (var i = 1; i <= n; i++)
        {                          
            document.write("<tr>");
            for (var j = 1; j <= n; j++)
            {
                molt = i * j;
                document.write("<td>" + molt + "</td>");
            }
            document.write("</tr>");
        }
     
