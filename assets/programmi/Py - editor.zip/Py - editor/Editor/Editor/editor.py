﻿import tkinter as tk
import webbrowser
import os
from tkinter import filedialog
from tkinter import messagebox

#Creato da Elio Gargiulo    

class BarraMenu: 

    # Costruttore/Main della Classe

    def __init__(self, parent):                                     
        
        tipoFont = ('Segoe UI', 9)                                  # Tipo del font
        barraMenu = tk.Menu(parent.disegnatore, font=tipoFont)      # Creo il menu
        parent.disegnatore.config(menu=barraMenu)                   # Dico all'editor che uso come menu la barra

        
        # Creo un altro menu che aggiunge gli elementi alla categoria file.... Command fa partire una funzione quando viene cliccata una Sezione

        elencoFile = tk.Menu(barraMenu, font=tipoFont, tearoff=0) 
        elencoFile.add_command(label="Nuovo File",                  # Sezione Nuovo File
                                  accelerator="Ctrl+N",
                                  command=parent.creaNuovoFile)
        elencoFile.add_command(label="Apri File",                   # Sezione Apri File
                                  accelerator="Ctrl+O",
                                  command=parent.apriFile)
        elencoFile.add_command(label="Salva File",                  # Sezione Salva File
                                  accelerator="Ctrl+S",
                                  command=parent.salvaFile)
        elencoFile.add_command(label="Salva con Nome",              # Sezione Salva con Nome
                                  accelerator="Ctrl+Shift+S",
                                  command=parent.salvaAs)
        elencoFile.add_separator()                                  # Aggiunge una linea tra le sezioni
        elencoFile.add_command(label="Esci", 
                                command=parent.disegnatore.destroy) # Esce dal Programma

        # Creo un altro menu che aggiunge gli elementi alla categoria ?.... Command fa partire una funzione quando viene cliccata una Sezione

        elencoPuntoDomanda = tk.Menu(barraMenu, font=tipoFont, tearoff=0)
        elencoPuntoDomanda.add_command(label="Aiuto",               # Sezione Aiuto
                                   command=self.mostraAiuto)
        elencoPuntoDomanda.add_separator() 
        elencoPuntoDomanda.add_command(label="Info",                # Sezione Informazioni
                                   command=self.mostraInfo)

        # Aggiungo infine le Categorie alla barraMenu
        barraMenu.add_cascade(label="File", menu=elencoFile)
        barraMenu.add_cascade(label="?", menu=elencoPuntoDomanda)
        
        # Funzione Aiuto
    def mostraAiuto(self):
        webbrowser.open('http://www.iccarmagnolaprimo.gov.it/index.php/didattica/giorno-prof/attivita/380-usare-un-editor-di-testo', new=2)
    def mostraInfo(self):
        titolo = "Informazioni"
        testo = "Editor di Testo sviluppato con Python.\nVersione 1.0 del Software\nCreato da Elio Gargiulo"
        messagebox.showinfo(titolo, testo)
        
        
class EditorTesto:
    
    # Costruttore/Main della Classe
    def __init__(self, disegnatore):

                                             
        disegnatore.title("Senza Titolo")                                        # Titolo della finestra     
        lunghezza = disegnatore.winfo_reqwidth()
        altezza = disegnatore.winfo_reqheight()
        destra = int(disegnatore.winfo_screenwidth()/3 - lunghezza/2)
        sinistra = int(disegnatore.winfo_screenheight()/3 - altezza /2)
        disegnatore.geometry("+{}+{}".format(destra, sinistra))                  # Dimensione finestra centrata
     

        font_specs = ('Consolas', 12)                                            # Font Usato

        self.disegnatore = disegnatore                                           # Attributi/Metodi
        self.nomeFile = None

        self.areaTesto = tk.Text(disegnatore, font=font_specs)                   # Creo un area di testo nella finestra
        self.scrollBar = tk.Scrollbar(disegnatore, command=self.areaTesto.yview) # Aggiungo la scrollbar
        self.areaTesto.configure(yscrollcommand=self.scrollBar.set)
        self.areaTesto.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)             # L'area occupa tutta la finestra
        self.scrollBar.pack(side=tk.RIGHT, fill=tk.Y)                            # La scrollbar viene messa a destra per tutta l'asse y    

        self.barraMenu = BarraMenu(self)                                         # Creo la Barra tramite la Classe
 
        self.tastiRapidi()                                                       # Assegno le shortcut
    
    # Funzione aggiorna il Titolo della Window al nome del file se inserito
    def titoloFinestra(self, nome):                                              
        if nome:
            self.disegnatore.title(nome)
        else:
            self.disegnatore.title("Senza Titolo")
    # Funzione che crea un nuovo file pulendo l'area e dando nome e titolo none => Senza Titolo (Args serve a passare informazioni dal file)
    def creaNuovoFile(self, *args):
        self.areaTesto.delete(1.0, tk.END)
        self.titoloFinestra("Senza Titolo")
    # Funzione che apre un file (Args serve a passare informazioni dal file)
    def apriFile(self,*args):
        self.nomeFile = filedialog.askopenfilename( # Fa apparire la classica interfaccia per aprire un file
            defaultextension=".txt",            # Estensione di default txt
            filetypes=[("Tutti i file", "*.*"), # Tipi di file che si possono aprire
                       ("File di Testo", "*.txt"),
                       ("Script Python", "*.py"),
                       ("File JavaScript", "*.js"),
                       ("Documenti HMTL", "*.html"),
                       ("Documenti CSS", "*.css")])
        if self.nomeFile: # Se c'è un nome
            self.areaTesto.delete(1.0, tk.END) # Pulisce l'editor
            with open(self.nomeFile, "r") as f:# Legge il file
                self.areaTesto.insert(1.0, f.read()) # Inserisce il testo del file nell'editor (read)
            self.titoloFinestra(os.path.basename(self.nomeFile)) # Aggiorna il titolo con il nome del file
    # Funzione che salva il file (Senza dare il nome nel caso sia già dato)
    def salvaFile(self, *args):
        if self.nomeFile: # Se esiste un nome
            try:
                contenuto = self.areaTesto.get(1.0, tk.END) # Salvo il contenuto del file
                with open(self.nomeFile, "w") as f: # E lo scrivo in un altro
                    f.write(contenuto)
            except Exception as e: # Nel caso ci sia un problema
                print(e)
        else:
            self.salvaAs() # Se non ha un nome usa questa funzione
    # Funzione che salva il file con nome
    def salvaAs(self, *args):
        try:
            nuovoFile = filedialog.asksaveasfilename( # Stessa roba del salva ma sta volta con un nome assegnabile
                initialfile='Senza Titolo.txt',       # Nome di default
                defaultextension=".txt",
	            filetypes=[("Tutti i file", "*.*"),
	                       ("File di Testo", "*.txt"),
	                       ("Script Python", "*.py"),
	                       ("Markdown Text", "*.md"),
	                       ("File JavaScript", "*.js"),
	                       ("Documenti HMTL", "*.html"),
	                       ("Documenti CSS", "*.css")])
            with open(nuovoFile, 'w') as f: # Creo File in Modalità scrittura
                contenutoFile = self.areaTesto.get(1.0, tk.END) # Salvo il contenuto dell'editor
                f.write(contenutoFile) # Scrivo il contenuto del nuovo file
            self.nomeFile = nuovoFile # Aggiorno il nome del file per il titolo
            self.titoloFinestra(os.path.basename(self.nomeFile)) # Aggiorno il titolo della Window
        
        except Exception as e: # Nel caso ci sia un problema
            print(e)

    def tastiRapidi(self):
        self.areaTesto.bind('<Control-n>', self.creaNuovoFile) # Associo ctrl n alla funzione creaNuovoFile
        self.areaTesto.bind('<Control-o>', self.apriFile)      # Associo ctrl o alla funzione apriFile
        self.areaTesto.bind('<Control-s>', self.salvaFile)     # Associo ctrl s alla funzione salvaFile
        self.areaTesto.bind('<Control-S>', self.salvaAs)       # Associo ctrl S alla funzione salvaAs
