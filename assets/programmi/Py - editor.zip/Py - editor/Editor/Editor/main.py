﻿import tkinter as tk
from editor import BarraMenu
from editor import EditorTesto

#Creato da Elio Gargiulo     

if __name__ == "__main__": # Se è settato come progretto di avvio la cond dell'if è true

    disegnatore = tk.Tk() # Creo una finestra per elementi grafici
    pt = EditorTesto(disegnatore) # Creo un editor di testo nella Window
    disegnatore.mainloop() # Mantiene Aperto il Programma

