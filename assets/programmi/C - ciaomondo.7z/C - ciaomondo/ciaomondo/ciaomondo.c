#include <stdio.h> //Includiamo la libreria standard che ci fornisce alcune funzioni fondamentali.

int main() //Main ovvero il compito principale del programma.
{
    printf("Ciao Mondo"); //Printf è la funzione che stampa in console la stringa (Ciao Mondo).
    return 0; //Essendo il main intero, deve sempre ritornare un valore, ovvero 0.
}